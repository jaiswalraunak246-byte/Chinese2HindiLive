
package com.example.chinese2hindilive

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.LayoutInflater
import android.view.WindowManager
import android.widget.TextView
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.nl.translate.Translation
import java.util.*

class FloatingService: Service(), TextToSpeech.OnInitListener {

    private lateinit var wm: WindowManager
    private lateinit var view: android.view.View
    private lateinit var tv: TextView
    private lateinit var sr: SpeechRecognizer
    private lateinit var tts: TextToSpeech

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 50; params.y = 100

        view = LayoutInflater.from(this).inflate(R.layout.floating_layout, null)
        tv = view.findViewById(R.id.tvSubtitle)
        wm.addView(view, params)

        startListening()
    }

    private fun startListening(){
        sr = SpeechRecognizer.createSpeechRecognizer(this)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "cmn-Hans-CN")

        sr.setRecognitionListener(object: android.speech.RecognitionListener {
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if(text!=null) translate(text)
                sr.startListening(intent)
            }
            override fun onError(error: Int){ sr.startListening(intent) }
            override fun onReadyForSpeech(p0: Bundle?) {} override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(p0: Float) {} override fun onBufferReceived(p0: ByteArray?) {}
            override fun onEndOfSpeech() {} override fun onPartialResults(p0: Bundle?) {}
            override fun onEvent(p0: Int,p1: Bundle?) {}
        })
        sr.startListening(intent)
    }

    private fun translate(text:String){
        val opt = TranslatorOptions.Builder()
            .setSourceLanguage("zh")
            .setTargetLanguage("hi")
            .build()
        val tr = Translation.getClient(opt)
        tr.downloadModelIfNeeded().addOnSuccessListener {
            tr.translate(text).addOnSuccessListener { out ->
                tv.text = out
                tts.speak(out, TextToSpeech.QUEUE_FLUSH, null, null)
            }
        }
    }

    override fun onInit(status: Int) {
        if(status==TextToSpeech.SUCCESS){
            tts.language = Locale("hi", "IN")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if(::view.isInitialized) wm.removeView(view)
        tts.shutdown()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
